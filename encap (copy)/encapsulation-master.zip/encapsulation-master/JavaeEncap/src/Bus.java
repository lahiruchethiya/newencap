
import java.util.ArrayList;


public class Bus {
    public static ArrayList<Bus> buses ;
    {
        buses= new ArrayList<>();
		buses.add(new Bus());
    }
    
}
